import java.io.*;
import java.net.*;
import java.util.*;

public class server {
    public static void main(String[] args) {
        try {
            String clientSentence;
            String capitalizedSentence;
            ServerSocket welcomeSocket = new ServerSocket(1234);

            while (true) {
                Socket connectionSocket = welcomeSocket.accept();
                BufferedReader inFromClient = new BufferedReader(
                        new InputStreamReader(connectionSocket.getInputStream()));
                DataOutputStream outToClient = new DataOutputStream(connectionSocket.getOutputStream());

                Thread thread = new Thread(() -> {
                    while (true) {
                        try {
                            String recive = String.valueOf(inFromClient.read());
                            System.out.println(recive);
                            outToClient.writeChars(recive);
                        } catch (IOException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                    }
                });

            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
