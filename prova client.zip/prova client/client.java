import java.io.*;
import java.net.*;
import java.util.*;

class client {

    public static void main(String[] args) {
        try {
            Socket socket = new Socket(InetAddress.getByName("localhost"), 1234);
            BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
            DataOutputStream outToServer = new DataOutputStream(socket.getOutputStream());
            outToServer.writeUTF("String.valueOf(i++)");

            TimerTask tt = new TimerTask() {
                int i = 0;

                @Override
                public void run() {
                    try {
                        outToServer.writeChars("String.valueOf(i++)");
                        System.out.print(inFromUser.readLine());
                    } catch (Exception e) {

                    }
                }
            };

            Timer timer = new Timer();
            timer.schedule(tt, 0, 25);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}